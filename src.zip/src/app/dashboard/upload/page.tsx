import FileUploader from "@/components/FileUploader";
import React from "react";

function UploadPage() {
  return (
    <div>
      <FileUploader />
    </div>
  );
}

export default UploadPage;
